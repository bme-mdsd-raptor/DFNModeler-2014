package GreenhouseDFNPackage;
	

public class PLCNode
{
	public enum State{
		PLCAtWarmDay, PLCAtWarmNight, PLCAtColdDay, PLCAtColdNight
	}
	
	State state = State.PLCAtWarmDay;

	PLCAtLightingCommandOutToLightingAtCommandInChannel PLCAtLightingCommandOutToLightingAtCommandInChannelInstance  = null;
		
	public void setPLCAtLightingCommandOutToLightingAtCommandInChannel(PLCAtLightingCommandOutToLightingAtCommandInChannel channel) {
		PLCAtLightingCommandOutToLightingAtCommandInChannelInstance = channel;
	}

	PLCAtHeatingCommandOutToHeatingAtCommandInChannel PLCAtHeatingCommandOutToHeatingAtCommandInChannelInstance  = null;
		
	public void setPLCAtHeatingCommandOutToHeatingAtCommandInChannel(PLCAtHeatingCommandOutToHeatingAtCommandInChannel channel) {
		PLCAtHeatingCommandOutToHeatingAtCommandInChannelInstance = channel;
	}

	
	DayPhaseToken PLCAtLightSensorInputInPortInstance = null;
	public void setInputOnPLCAtLightSensorInputInPort(DayPhaseToken token)
	{			
		PLCAtLightSensorInputInPortInstance = token;
				
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue())
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
	}
	
	
	TemperatureToken PLCAtTempSensorInputInPortInstance = null;
	public void setInputOnPLCAtTempSensorInputInPort(TemperatureToken token)
	{			
		PLCAtTempSensorInputInPortInstance = token;
				
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmNight -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdDay && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdDay -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue())
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtColdDay");
				state = State.PLCAtColdDay;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseDay == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtWarmDay");
				state = State.PLCAtWarmDay;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOff);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtColdNight && PLCAtTempSensorInputInPortInstance!=null && 20 <= PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtColdNight -> PLCAtWarmNight");
				state = State.PLCAtWarmNight;
				
				
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOff);
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				
				return;
				
			}
			
		//transition
			
		if (state == State.PLCAtWarmDay && PLCAtTempSensorInputInPortInstance!=null && 20 > PLCAtTempSensorInputInPortInstance.getValue() && PLCAtLightSensorInputInPortInstance!=null && DayPhaseToken.DayPhaseNight == PLCAtLightSensorInputInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: PLCNode");	
				System.out.println("PLCAtWarmDay -> PLCAtColdNight");
				state = State.PLCAtColdNight;
				
				
				setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken.LightsOn);
				setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken.HeatingOn);
				
				return;
				
			}
			
	}
	
	
	public void setOutputOnPLCAtLightingCommandOutToLightingAtCommandInChannel(LightsToken token)
	{					
		PLCAtLightingCommandOutToLightingAtCommandInChannelInstance.setToken(token);
	}
	
	
	public void setOutputOnPLCAtHeatingCommandOutToHeatingAtCommandInChannel(HeatingToken token)
	{					
		PLCAtHeatingCommandOutToHeatingAtCommandInChannelInstance.setToken(token);
	}
	
}
