package GreenhouseDFNPackage;
	

public class PLCAtLightingCommandOutToLightingAtCommandInChannel
{
	LightingNode target = new LightingNode();
	
	public void setTarget(LightingNode target)
	{
		this.target=target;
	}
	
	public void setToken(LightsToken token)
	{
		target.setInputOnLightingAtCommandInInPort(token);
	}
}
