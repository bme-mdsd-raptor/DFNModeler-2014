package GreenhouseDFNPackage;
	

public class HeatingNode
{
	public enum State{
		HeatingAtOn, HeatingAtOff
	}
	
	State state = State.HeatingAtOff;

	
	HeatingToken HeatingAtCommandInInPortInstance = null;
	public void setInputOnHeatingAtCommandInInPort(HeatingToken token)
	{			
		HeatingAtCommandInInPortInstance = token;
				
		//transition
			
		if (state == State.HeatingAtOff && HeatingAtCommandInInPortInstance!=null && HeatingToken.HeatingOff == HeatingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: HeatingNode");	
				System.out.println("HeatingAtOff -> HeatingAtOff");
				state = State.HeatingAtOff;
				
				
				return;
				
			}
			
		//transition
			
		if (state == State.HeatingAtOn && HeatingAtCommandInInPortInstance!=null && HeatingToken.HeatingOff == HeatingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: HeatingNode");	
				System.out.println("HeatingAtOn -> HeatingAtOff");
				state = State.HeatingAtOff;
				
				
				return;
				
			}
			
		//transition
			
		if (state == State.HeatingAtOff && HeatingAtCommandInInPortInstance!=null && HeatingToken.HeatingOn == HeatingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: HeatingNode");	
				System.out.println("HeatingAtOff -> HeatingAtOn");
				state = State.HeatingAtOn;
				
				
				return;
				
			}
			
		//transition
			
		if (state == State.HeatingAtOn && HeatingAtCommandInInPortInstance!=null && HeatingToken.HeatingOn == HeatingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: HeatingNode");	
				System.out.println("HeatingAtOn -> HeatingAtOn");
				state = State.HeatingAtOn;
				
				
				return;
				
			}
			
	}
	
}
