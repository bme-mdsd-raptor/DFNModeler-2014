package GreenhouseDFNPackage;

public enum LightsToken{
	LightsOn, LightsOff
}

