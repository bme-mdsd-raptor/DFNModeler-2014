package GreenhouseDFNPackage;
	

public class HouseLightSensorPLCLightSensorInputChannel
{
	PLCNode target = new PLCNode();
	
	public void setTarget(PLCNode target)
	{
		this.target=target;
	}
	
	public void setToken(DayPhaseToken token)
	{
		target.setInputOnPLCLightSensorInputInPort(token);
	}
}
