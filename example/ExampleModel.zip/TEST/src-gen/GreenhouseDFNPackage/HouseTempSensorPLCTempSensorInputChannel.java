package GreenhouseDFNPackage;
	

public class HouseTempSensorPLCTempSensorInputChannel
{
	PLCNode target = new PLCNode();
	
	public void setTarget(PLCNode target)
	{
		this.target=target;
	}
	
	public void setToken(TemperatureToken token)
	{
		target.setInputOnPLCTempSensorInputInPort(token);
	}
}
