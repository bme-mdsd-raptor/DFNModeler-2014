package GreenhouseDFNPackage;

public enum HeatingToken{
	HeatingOn, HeatingOff
}

