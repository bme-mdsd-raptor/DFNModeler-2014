package GreenhouseDFNPackage;
	

public class PLCLightingCommandOutLightingCommandInChannel
{
	LightingNode target = new LightingNode();
	
	public void setTarget(LightingNode target)
	{
		this.target=target;
	}
	
	public void setToken(LightsToken token)
	{
		target.setInputOnLightingCommandInInPort(token);
	}
}
