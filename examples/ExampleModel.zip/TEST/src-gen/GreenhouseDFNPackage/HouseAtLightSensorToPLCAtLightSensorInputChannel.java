package GreenhouseDFNPackage;
	

public class HouseAtLightSensorToPLCAtLightSensorInputChannel
{
	PLCNode target = new PLCNode();
	
	public void setTarget(PLCNode target)
	{
		this.target=target;
	}
	
	public void setToken(DayPhaseToken token)
	{
		target.setInputOnPLCAtLightSensorInputInPort(token);
	}
}
