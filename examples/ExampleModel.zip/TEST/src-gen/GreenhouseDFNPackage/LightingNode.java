package GreenhouseDFNPackage;
	

public class LightingNode
{
	public enum State{
		LightingAtOn, LightingAtOff
	}
	
	State state = State.LightingAtOff;

	
	LightsToken LightingAtCommandInInPortInstance = null;
	public void setInputOnLightingAtCommandInInPort(LightsToken token)
	{			
		LightingAtCommandInInPortInstance = token;
				
		//transition
			
		if (state == State.LightingAtOff && LightingAtCommandInInPortInstance!=null && LightsToken.LightsOn == LightingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: LightingNode");	
				System.out.println("LightingAtOff -> LightingAtOn");
				state = State.LightingAtOn;
				
				
				return;
				
			}
			
		//transition
			
		if (state == State.LightingAtOff && LightingAtCommandInInPortInstance!=null && LightsToken.LightsOff == LightingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: LightingNode");	
				System.out.println("LightingAtOff -> LightingAtOff");
				state = State.LightingAtOff;
				
				
				return;
				
			}
			
		//transition
			
		if (state == State.LightingAtOn && LightingAtCommandInInPortInstance!=null && LightsToken.LightsOff == LightingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: LightingNode");	
				System.out.println("LightingAtOn -> LightingAtOff");
				state = State.LightingAtOff;
				
				
				return;
				
			}
			
		//transition
			
		if (state == State.LightingAtOn && LightingAtCommandInInPortInstance!=null && LightsToken.LightsOn == LightingAtCommandInInPortInstance)
			{
				System.out.println("GreenhouseDFNPackage: LightingNode");	
				System.out.println("LightingAtOn -> LightingAtOn");
				state = State.LightingAtOn;
				
				
				return;
				
			}
			
	}
	
}
