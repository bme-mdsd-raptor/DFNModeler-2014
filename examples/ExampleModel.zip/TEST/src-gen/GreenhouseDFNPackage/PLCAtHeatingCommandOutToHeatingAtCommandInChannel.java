package GreenhouseDFNPackage;
	

public class PLCAtHeatingCommandOutToHeatingAtCommandInChannel
{
	HeatingNode target = new HeatingNode();
	
	public void setTarget(HeatingNode target)
	{
		this.target=target;
	}
	
	public void setToken(HeatingToken token)
	{
		target.setInputOnHeatingAtCommandInInPort(token);
	}
}
