package GreenhouseDFNPackage;
	

public class HouseAtTempSensorToPLCAtTempSensorInputChannel
{
	PLCNode target = new PLCNode();
	
	public void setTarget(PLCNode target)
	{
		this.target=target;
	}
	
	public void setToken(TemperatureToken token)
	{
		target.setInputOnPLCAtTempSensorInputInPort(token);
	}
}
