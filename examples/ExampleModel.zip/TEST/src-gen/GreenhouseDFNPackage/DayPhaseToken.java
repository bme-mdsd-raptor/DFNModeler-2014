package GreenhouseDFNPackage;

public enum DayPhaseToken{
	DayPhaseDay, DayPhaseNight
}

