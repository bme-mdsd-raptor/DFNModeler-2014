package GreenhouseDFNPackage;
	

public class GreenhouseDFN
{
	HeatingNode HeatingNodeInstance = new HeatingNode();
	LightingNode LightingNodeInstance = new LightingNode();
	PLCNode PLCNodeInstance = new PLCNode();
	HouseAtLightSensorToPLCAtLightSensorInputChannel HouseAtLightSensorToPLCAtLightSensorInputChannelInstance = new HouseAtLightSensorToPLCAtLightSensorInputChannel();
	HouseAtTempSensorToPLCAtTempSensorInputChannel HouseAtTempSensorToPLCAtTempSensorInputChannelInstance = new HouseAtTempSensorToPLCAtTempSensorInputChannel();
	PLCAtLightingCommandOutToLightingAtCommandInChannel PLCAtLightingCommandOutToLightingAtCommandInChannelInstance = new PLCAtLightingCommandOutToLightingAtCommandInChannel();
	PLCAtHeatingCommandOutToHeatingAtCommandInChannel PLCAtHeatingCommandOutToHeatingAtCommandInChannelInstance = new PLCAtHeatingCommandOutToHeatingAtCommandInChannel();
	
	public GreenhouseDFN() {
		PLCNodeInstance.setPLCAtLightingCommandOutToLightingAtCommandInChannel(PLCAtLightingCommandOutToLightingAtCommandInChannelInstance);
		PLCNodeInstance.setPLCAtHeatingCommandOutToHeatingAtCommandInChannel(PLCAtHeatingCommandOutToHeatingAtCommandInChannelInstance);
		HouseAtLightSensorToPLCAtLightSensorInputChannelInstance.setTarget(PLCNodeInstance);
		HouseAtTempSensorToPLCAtTempSensorInputChannelInstance.setTarget(PLCNodeInstance);
		PLCAtLightingCommandOutToLightingAtCommandInChannelInstance.setTarget(LightingNodeInstance);
		PLCAtHeatingCommandOutToHeatingAtCommandInChannelInstance.setTarget(HeatingNodeInstance);
	}
	
	public void setOutputOnHouseAtLightSensorToPLCAtLightSensorInputChannel(DayPhaseToken token)
	{					
		HouseAtLightSensorToPLCAtLightSensorInputChannelInstance.setToken(token);
	}
	
	
	public void setOutputOnHouseAtTempSensorToPLCAtTempSensorInputChannel(TemperatureToken token)
	{					
		HouseAtTempSensorToPLCAtTempSensorInputChannelInstance.setToken(token);
	}
	
}
